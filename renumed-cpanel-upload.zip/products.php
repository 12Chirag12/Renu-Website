<?php
$page_title = 'Products & Formulations — Tablets & Capsules — Renumed Pharma';
$page_desc  = 'Explore Renumed Pharmaceutical Labs solid oral dosage manufacturing capabilities — specialized in pharmaceutical tablets and capsules.';
require 'includes/head.php';
require 'includes/header.php';
?>


<!-- ── Primary Dosage Explorer ───────────────────────────── -->
<section class="page-bg-mist" style="padding-block:72px">
  <div class="container-shell">
    <div class="section-heading centered">
      <span class="section-kicker">Primary Dosage Forms</span>
      <h1 style="margin-top:18px">Tablets &amp; Capsules Manufacturing Scope.</h1>
      <p class="section-body" style="max-width:680px;margin-inline:auto">Toggle between Tablets and Capsules below to inspect our coating methods, technical tooling, release profiles, and blister packaging configurations.</p>
    </div>

    <!-- Tab Switcher -->
    <div style="display:flex;justify-content:center;margin-top:40px">
      <div style="display:inline-flex;border-radius:18px;background:#fff;padding:6px;box-shadow:0 4px 16px rgba(15,27,61,.06);border:1px solid #e2e8f0;gap:6px">
        <button type="button" class="dosage-tab active" data-target="panel-tablets" style="display:inline-flex;align-items:center;gap:10px;border-radius:12px;padding:12px 24px;font-size:.875rem;font-weight:700;cursor:pointer;border:0;transition:all .25s">
          <span style="display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:var(--cyan);color:var(--navy);font-size:.75rem;font-weight:800">TB</span>
          Tablets Formulation
        </button>
        <button type="button" class="dosage-tab" data-target="panel-capsules" style="display:inline-flex;align-items:center;gap:10px;border-radius:12px;padding:12px 24px;font-size:.875rem;font-weight:700;cursor:pointer;border:0;transition:all .25s">
          <span style="display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:#f1f5f9;color:#64748b;font-size:.75rem;font-weight:800">CP</span>
          Capsules Formulation
        </button>
      </div>
    </div>

    <!-- ── Tablets Panel ── -->
    <div id="panel-tablets" class="dosage-panel active" style="margin-top:36px">
      <div style="border-radius:24px;border:1px solid #e2e8f0;background:#fff;padding:32px;box-shadow:0 12px 32px rgba(15,27,61,.05)">
        
        <!-- Header -->
        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:20px;border-bottom:1px solid #f1f5f9;padding-bottom:28px">
          <div>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="display:inline-flex;align-items:center;gap:6px;border-radius:999px;background:rgba(25,182,207,.15);padding:4px 12px;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--petrol)">
                <span style="width:6px;height:6px;border-radius:50%;background:var(--cyan)"></span>
                Solid Oral Formulation
              </span>
              <span style="font-size:.75rem;font-weight:600;color:var(--slate-400)">Code: TB</span>
            </div>
            <h3 style="margin-top:12px;font-size:1.75rem;font-weight:800;color:var(--navy)">Precision Compression &amp; Coating Capabilities</h3>
            <p style="margin-top:8px;max-width:760px;font-size:.925rem;line-height:1.65;color:var(--slate-600)">Our tablet manufacturing infrastructure supports high-speed rotary compression, advanced aqueous and organic film coating, and modified-release formulation profiles with stringent weight uniformity.</p>
          </div>
          <div style="flex-shrink:0">
            <a href="/contact.php?interest=Tablet%20Contract%20Manufacturing" class="btn-primary" style="padding:12px 22px;font-size:.875rem">
              Enquire for Tablets
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/></svg>
            </a>
          </div>
        </div>

        <!-- Annual Production Capacity Box -->
        <div style="margin-top:28px;border-radius:20px;border:1px solid rgba(25,182,207,.3);background:linear-gradient(135deg,#f8fafc 0%,#fff 60%,rgba(25,182,207,.08) 100%);padding:24px">
          <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px">
            <div style="display:flex;align-items:center;gap:10px">
              <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--cyan);box-shadow:0 0 8px #19b6cf"></span>
              <span style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--slate-500)">Annual Production Capacity</span>
            </div>
            <span style="border-radius:999px;background:rgba(25,182,207,.15);padding:4px 12px;font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--petrol)">Verified Commercial Scale • Per Annum Only</span>
          </div>
          <div style="margin-top:16px;display:flex;flex-wrap:wrap;align-items:baseline;gap:16px">
            <div class="js-counter display-face" data-target="1500" data-suffix="+" style="font-size:3rem;font-weight:800;color:var(--navy);font-family:monospace">1500+</div>
            <div>
              <span style="font-size:1.15rem;font-weight:700;color:var(--petrol);display:block">
                Million Tablets <span style="font-size:.8rem;font-weight:600;color:var(--slate-500);text-transform:uppercase;letter-spacing:.08em">/ annum</span>
              </span>
              <span style="font-size:.78rem;color:var(--slate-500)">Installed multi-station rotary punching lines supporting multi-million commercial runs.</span>
            </div>
          </div>
          <!-- Micro-specs -->
          <div style="margin-top:18px;display:flex;flex-wrap:wrap;gap:8px;padding-top:16px;border-top:1px solid rgba(226,232,240,.7)">
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--cyan)"></span>High-Speed Rotary Compression</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--cyan)"></span>Aqueous &amp; Enteric Film Coating</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--cyan)"></span>Bilayer Incompatibility Separation</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--cyan)"></span>Alu-Alu &amp; PVC/PVDC Packing</span>
          </div>
        </div>

        <!-- 6 Variations Grid -->
        <div style="margin-top:36px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--petrol)">Supported Tablets Types &amp; Formats</h4>
            <span style="font-size:.75rem;color:var(--slate-400)">6 Specialized Variations</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:20px">
            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M12.516 2.17a.75.75 0 00-1.032 0 11.209 11.209 0 01-7.877 3.08.75.75 0 00-.722.515A12.74 12.74 0 002.25 9.75c0 5.942 4.064 10.933 9.563 12.348a.749.749 0 00.374 0c5.499-1.415 9.563-6.406 9.563-12.348 0-1.39-.223-2.73-.635-3.985a.75.75 0 00-.722-.516l-.143.001c-2.996 0-5.717-1.17-7.734-3.08z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">01</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Film-Coated Tablets</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Aqueous and organic polymer film coatings protecting sensitive APIs and improving swallowability.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path d="M11.644 1.59a.75.75 0 01.712 0l9.75 5.25a.75.75 0 010 1.32l-9.75 5.25a.75.75 0 01-.712 0l-9.75-5.25a.75.75 0 010-1.32l9.75-5.25z"/><path d="M3.265 10.602l7.668 4.129a2.25 2.25 0 002.134 0l7.668-4.13 1.37.739a.75.75 0 010 1.32l-9.75 5.25a.75.75 0 01-.712 0l-9.75-5.25a.75.75 0 010-1.32l1.37-.738z"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">02</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Enteric-Coated Tablets</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">pH-dependent polymers designed for targeted intestinal drug release and gastric protection.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12.75 6a.75.75 0 00-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 000-1.5h-3.75V6z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">03</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Sustained &amp; Extended Release</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Hydrophilic and lipid matrix systems for controlled API release kinetics over extended periods.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.576 2.576l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-2.576 2.576l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.576-2.576l-2.846-.813a.75.75 0 010-1.442l2.846-.813A3.75 3.75 0 007.466 7.89l.813-2.846A.75.75 0 019 4.5z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">04</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Dispersible &amp; Chewable</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Fast-disintegrating formulations engineered for rapid oral dispersion and high patient adherence.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path d="M12 2.25a.75.75 0 01.75.75v18a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12z"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">05</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Bilayer &amp; Multilayer Tablets</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Specialized dual-layer compression separating incompatible actives or providing biphasic release.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M7.5 3.75A1.5 1.5 0 006 5.25v13.5a1.5 1.5 0 001.5 1.5h6a1.5 1.5 0 001.5-1.5V5.25a1.5 1.5 0 00-1.5-1.5h-6zm.75 3a.75.75 0 01.75-.75h4.5a.75.75 0 010 1.5H9a.75.75 0 01-.75-.75zm0 3a.75.75 0 01.75-.75h4.5a.75.75 0 010 1.5H9a.75.75 0 01-.75-.75zm0 3a.75.75 0 01.75-.75h4.5a.75.75 0 010 1.5H9a.75.75 0 01-.75-.75z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">06</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Uncoated Compressed Tablets</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">High-hardness, low-friability core tablets manufactured under strictly controlled environmental humidity.</p>
            </div>
          </div>
        </div>

        <!-- Technical Specs & Packaging -->
        <div style="margin-top:36px;display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;border-radius:20px;background:#f8fafc;padding:24px">
          <div>
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--navy);margin-bottom:16px">Technical &amp; Machine Specifications</h4>
            <div style="display:grid;gap:10px">
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Annual Capacity</span><span style="font-weight:700;color:var(--navy)">1,500+ Million Tablets / annum</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Core Shapes</span><span style="font-weight:700;color:var(--navy)">Round, Oval, Oblong, Caplet, Custom shapes</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Identification</span><span style="font-weight:700;color:var(--navy)">Custom debossing, break-line scoring</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Tablet Diameters</span><span style="font-weight:700;color:var(--navy)">5mm to 22mm customizable tooling</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Batch Sizing</span><span style="font-weight:700;color:var(--navy)">Pilot, clinical, and commercial scale runs</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Quality Checks</span><span style="font-weight:700;color:var(--navy)">Friability, Hardness, Disintegration, Weight</span></div>
            </div>
          </div>

          <div>
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--navy);margin-bottom:16px">Approved Packaging Formats</h4>
            <div style="display:grid;gap:10px">
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>Alu-Alu Cold Form Blister Packaging (Maximum moisture barrier)</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>PVC / PVDC Blister Packaging (Crystal clear presentation)</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>Child-Resistant &amp; Senior-Friendly Blister Strips</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>High-Density Polyethylene (HDPE) Bottles with induction sealing</div>
            </div>

            <div style="margin-top:20px;padding-top:16px;border-top:1px solid #e2e8f0">
              <span style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--slate-400)">Target Therapies:</span>
              <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">Antibiotics &amp; Anti-infectives</span>
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">Cardiovascular</span>
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">Analgesic &amp; NSAIDs</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ── Capsules Panel ── -->
    <div id="panel-capsules" class="dosage-panel" style="margin-top:36px;display:none">
      <div style="border-radius:24px;border:1px solid #e2e8f0;background:#fff;padding:32px;box-shadow:0 12px 32px rgba(15,27,61,.05)">
        
        <!-- Header -->
        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:20px;border-bottom:1px solid #f1f5f9;padding-bottom:28px">
          <div>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="display:inline-flex;align-items:center;gap:6px;border-radius:999px;background:rgba(8,107,120,.15);padding:4px 12px;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--petrol)">
                <span style="width:6px;height:6px;border-radius:50%;background:var(--petrol)"></span>
                Encapsulation Technology
              </span>
              <span style="font-size:.75rem;font-weight:600;color:var(--slate-400)">Code: CP</span>
            </div>
            <h3 style="margin-top:12px;font-size:1.75rem;font-weight:800;color:var(--navy)">Versatile Encapsulation for Powders, Pellets &amp; Granules</h3>
            <p style="margin-top:8px;max-width:760px;font-size:.925rem;line-height:1.65;color:var(--slate-600)">Precision capsule filling technology engineered for uniform fill weights, sensitive active pharmaceutical ingredients, and customized shell specifications.</p>
          </div>
          <div style="flex-shrink:0">
            <a href="/contact.php?interest=Capsule%20Contract%20Manufacturing" class="btn-primary" style="padding:12px 22px;font-size:.875rem">
              Enquire for Capsules
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/></svg>
            </a>
          </div>
        </div>

        <!-- Annual Production Capacity Box -->
        <div style="margin-top:28px;border-radius:20px;border:1px solid rgba(8,107,120,.3);background:linear-gradient(135deg,#f8fafc 0%,#fff 60%,rgba(8,107,120,.08) 100%);padding:24px">
          <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px">
            <div style="display:flex;align-items:center;gap:10px">
              <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--petrol);box-shadow:0 0 8px #086b78"></span>
              <span style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--slate-500)">Annual Production Capacity</span>
            </div>
            <span style="border-radius:999px;background:rgba(8,107,120,.15);padding:4px 12px;font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--navy)">Verified Commercial Scale • Per Annum Only</span>
          </div>
          <div style="margin-top:16px;display:flex;flex-wrap:wrap;align-items:baseline;gap:16px">
            <div class="js-counter display-face" data-target="960" data-suffix="+" style="font-size:3rem;font-weight:800;color:var(--navy);font-family:monospace">960+</div>
            <div>
              <span style="font-size:1.15rem;font-weight:700;color:var(--petrol);display:block">
                Million Capsules <span style="font-size:.8rem;font-weight:600;color:var(--slate-500);text-transform:uppercase;letter-spacing:.08em">/ annum</span>
              </span>
              <span style="font-size:.78rem;color:var(--slate-500)">Precision automatic encapsulation suites for powder blends, micro-pellets, and controlled fills.</span>
            </div>
          </div>
          <!-- Micro-specs -->
          <div style="margin-top:18px;display:flex;flex-wrap:wrap;gap:8px;padding-top:16px;border-top:1px solid rgba(226,232,240,.7)">
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--petrol)"></span>Automatic Encapsulation (Sizes 00–4)</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--petrol)"></span>Vegetarian HPMC &amp; Gelatin Shells</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--petrol)"></span>Multi-Unit Pellet System (MUPS)</span>
            <span style="display:inline-flex;align-items:center;gap:6px;border-radius:8px;background:#fff;padding:6px 12px;font-size:.75rem;font-weight:600;color:var(--slate-700);border:1px solid #e2e8f0"><span style="width:6px;height:6px;border-radius:50%;background:var(--petrol)"></span>Tamper-Evident Banding</span>
          </div>
        </div>

        <!-- 6 Variations Grid -->
        <div style="margin-top:36px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--petrol)">Supported Capsules Types &amp; Formats</h4>
            <span style="font-size:.75rem;color:var(--slate-400)">6 Specialized Variations</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:20px">
            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path d="M12.378 1.602a.75.75 0 00-.756 0L3 6.632l9 5.25 9-5.25-8.622-5.03zM21.75 7.93l-9 5.25v9.44a.75.75 0 00.378.65l8.622-5.03a.75.75 0 00.378-.65V7.93zM11.25 22.62v-9.44l-9-5.25v9.44a.75.75 0 00.378.65l8.622 5.03z"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">01</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Hard Gelatin Capsules (HGC)</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Standard pharmaceutical-grade gelatin shells with rapid disintegration in gastric fluid.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.576 2.576l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-2.576 2.576l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.576-2.576l-2.846-.813a.75.75 0 010-1.442l2.846-.813A3.75 3.75 0 007.466 7.89l.813-2.846A.75.75 0 019 4.5z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">02</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Vegetarian (HPMC) Capsules</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Plant-derived hypromellose shells with low moisture content (&lt;7%), ideal for hygroscopic APIs.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path d="M11.644 1.59a.75.75 0 01.712 0l9.75 5.25a.75.75 0 010 1.32l-9.75 5.25a.75.75 0 01-.712 0l-9.75-5.25a.75.75 0 010-1.32l9.75-5.25z"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">03</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Pellets-in-Capsule (MUPS)</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Controlled-release micro-pellets and coated beads filled with precise multi-unit dosage accuracy.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M12.516 2.17a.75.75 0 00-1.032 0 11.209 11.209 0 01-7.877 3.08.75.75 0 00-.722.515A12.74 12.74 0 002.25 9.75c0 5.942 4.064 10.933 9.563 12.348a.749.749 0 00.374 0c5.499-1.415 9.563-6.406 9.563-12.348 0-1.39-.223-2.73-.635-3.985a.75.75 0 00-.722-.516l-.143.001c-2.996 0-5.717-1.17-7.734-3.08z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">04</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Delayed / Enteric Capsules</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Acid-resistant capsule shells protecting acid-labile molecules without needing solvent coating.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12.75 6a.75.75 0 00-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 000-1.5h-3.75V6z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">05</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Combination Fills</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Dual filling capabilities such as tablet-in-capsule or multi-pellet formulations for combination therapy.</p>
            </div>

            <div class="reveal-card" style="border-radius:16px;border:1px solid #e2e8f0;background:#f8fafc;padding:20px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:10px;background:#fff;color:var(--petrol);border:1px solid #e2e8f0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.74a.75.75 0 011.04-.207z" clip-rule="evenodd"/></svg>
                </span>
                <span style="font-size:.75rem;font-weight:700;color:var(--slate-400)">06</span>
              </div>
              <h5 style="margin-top:14px;font-weight:700;color:var(--navy);font-size:.95rem">Banded &amp; Tamper-Evident</h5>
              <p style="margin-top:6px;font-size:.78rem;line-height:1.55;color:var(--slate-600)">Hermetically sealed gelatin or HPMC liquid banding around the joint for tamper evidence and stability.</p>
            </div>
          </div>
        </div>

        <!-- Technical Specs & Packaging -->
        <div style="margin-top:36px;display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;border-radius:20px;background:#f8fafc;padding:24px">
          <div>
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--navy);margin-bottom:16px">Technical &amp; Machine Specifications</h4>
            <div style="display:grid;gap:10px">
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Annual Capacity</span><span style="font-weight:700;color:var(--navy)">960+ Million Capsules / annum</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Available Sizes</span><span style="font-weight:700;color:var(--navy)">Size 00, Size 0, Size 1, Size 2, Size 3, Size 4</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Shell Appearance</span><span style="font-weight:700;color:var(--navy)">Opaque, Transparent, Two-tone color</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Fill Formats</span><span style="font-weight:700;color:var(--navy)">Powder blends, Granules, Micro-pellets</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Moisture Levels</span><span style="font-weight:700;color:var(--navy)">HPMC: 3-7% | Gelatin: 13-16% equilibrium</span></div>
              <div style="display:flex;justify-content:space-between;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0"><span style="color:var(--slate-500);font-weight:600">Quality Checks</span><span style="font-weight:700;color:var(--navy)">Weight consistency, Shell integrity</span></div>
            </div>
          </div>

          <div>
            <h4 style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--navy);margin-bottom:16px">Approved Packaging Formats</h4>
            <div style="display:grid;gap:10px">
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>Alu-Alu Cold Form Blister Packs for moisture-sensitive formulations</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>PVC/PVDC Blister Packs with foil backing</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>Wide-mouth HDPE Bottles with silica gel caps</div>
              <div style="display:flex;align-items:center;gap:12px;border-radius:10px;background:#fff;padding:12px 16px;font-size:.78rem;border:1px solid #e2e8f0;font-weight:600;color:var(--slate-700)"><span style="display:grid;place-items:center;width:18px;height:18px;border-radius:50%;background:var(--petrol);color:#fff;font-size:10px">✓</span>Tamper-evident induction seal and outer carton packaging</div>
            </div>

            <div style="margin-top:20px;padding-top:16px;border-top:1px solid #e2e8f0">
              <span style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--slate-400)">Target Therapies:</span>
              <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">PPIs (Enteric Pellets)</span>
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">Antibiotics</span>
                <span style="border-radius:6px;background:#fff;border:1px solid #e2e8f0;padding:4px 10px;font-size:.72rem;font-weight:600;color:var(--slate-700)">Probiotics (HPMC)</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>
</section>

<!-- ── Comparison & Capability Highlights ────────────────── -->
<section class="page-bg-white" style="padding-block:80px;border-block:1px solid #f1f5f9">
  <div class="container-shell">
    <div class="section-heading">
      <span class="section-kicker">Dosage Highlights</span>
      <h2 style="margin-top:18px">Engineered for stability, precision, and bioavailability.</h2>
      <p>Our manufacturing facilities are optimized for solid oral dosage forms, ensuring tight weight tolerances and repeatable release profiles.</p>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;margin-top:48px">
      <!-- Tablets Feature Box -->
      <div class="reveal-card" style="border-radius:24px;border:1px solid #e2e8f0;background:rgba(248,250,252,.7);padding:32px">
        <div style="display:flex;align-items:center;gap:12px">
          <span style="display:grid;place-items:center;width:48px;height:48px;border-radius:12px;background:var(--navy);color:var(--cyan);font-size:.75rem;font-weight:800;letter-spacing:.1em">TB</span>
          <div>
            <h3 style="font-size:1.25rem;font-weight:800;color:var(--navy)">Tablets Advantage</h3>
            <p style="font-size:.75rem;color:var(--slate-500)">Compression &amp; Coating Science</p>
          </div>
        </div>
        <ul style="margin-top:24px;display:grid;gap:12px;font-size:.875rem;line-height:1.6;color:var(--slate-600);list-style:none">
          <li style="display:flex;gap:10px"><span style="color:var(--cyan);font-weight:800">•</span><span><strong>1,500+ Million Tablets / Annum:</strong> High-speed rotary compression output with automated weight verification.</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--cyan);font-weight:800">•</span><span><strong>Film &amp; Enteric Polymer Coating:</strong> Complete moisture, light, and acid protection.</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--cyan);font-weight:800">•</span><span><strong>Modified Release Systems:</strong> Matrix tablets offering sustained 12h/24h therapeutic release.</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--cyan);font-weight:800">•</span><span><strong>Multilayer Formulation:</strong> Physical barrier separation for dual-action combinations.</span></li>
        </ul>
        <div style="margin-top:28px;padding-top:20px;border-top:1px solid #e2e8f0">
          <a href="/contact.php?interest=Tablet%20Contract%20Manufacturing" style="display:inline-flex;align-items:center;gap:8px;font-size:.75rem;font-weight:700;color:var(--petrol)">
            Enquire for Tablet Formulations
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/></svg>
          </a>
        </div>
      </div>

      <!-- Capsules Feature Box -->
      <div class="reveal-card" style="border-radius:24px;border:1px solid #e2e8f0;background:rgba(248,250,252,.7);padding:32px">
        <div style="display:flex;align-items:center;gap:12px">
          <span style="display:grid;place-items:center;width:48px;height:48px;border-radius:12px;background:var(--petrol);color:#fff;font-size:.75rem;font-weight:800;letter-spacing:.1em">CP</span>
          <div>
            <h3 style="font-size:1.25rem;font-weight:800;color:var(--navy)">Capsules Advantage</h3>
            <p style="font-size:.75rem;color:var(--slate-500)">Encapsulation &amp; Filling Technology</p>
          </div>
        </div>
        <ul style="margin-top:24px;display:grid;gap:12px;font-size:.875rem;line-height:1.6;color:var(--slate-600);list-style:none">
          <li style="display:flex;gap:10px"><span style="color:var(--petrol);font-weight:800">•</span><span><strong>960+ Million Capsules / Annum:</strong> Precision automatic encapsulation for powder blends, micro-pellets, and granules.</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--petrol);font-weight:800">•</span><span><strong>HPMC &amp; Gelatin Compatibility:</strong> Vegetarian and standard shells across all standard sizes (00 to 4).</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--petrol);font-weight:800">•</span><span><strong>Pellet &amp; Granule Encapsulation:</strong> Enteric-coated micro-beads filled with high dosage accuracy.</span></li>
          <li style="display:flex;gap:10px"><span style="color:var(--petrol);font-weight:800">•</span><span><strong>Sensitive API Protection:</strong> Low-moisture shells protecting moisture-labile actives from degradation.</span></li>
        </ul>
        <div style="margin-top:28px;padding-top:20px;border-top:1px solid #e2e8f0">
          <a href="/contact.php?interest=Capsule%20Contract%20Manufacturing" style="display:inline-flex;align-items:center;gap:8px;font-size:.75rem;font-weight:700;color:var(--petrol)">
            Enquire for Capsule Formulations
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/></svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── CTA ──────────────────────────────────────────────── -->
<section class="cta-navy" style="padding-block:80px;text-align:center">
  <div class="container-narrow">
    <span class="section-kicker" style="color:var(--cyan)">Need a custom formulation?</span>
    <h2 style="margin-top:18px;color:#fff;font-size:2rem">Discuss your tablet or capsule specification.</h2>
    <p style="margin-top:14px;color:rgba(255,255,255,.8);font-size:.95rem;line-height:1.7;max-width:580px;margin-inline:auto">Share your active ingredient profile, target strength, batch scale, and packaging preferences. We provide technical feasibility feedback within 24 hours.</p>
    <div style="margin-top:32px">
      <a href="/contact.php" class="btn-primary" style="background:#fff;color:var(--navy);padding:14px 28px;font-size:.95rem">
        Request Feasibility Review
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="icon-sm" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/></svg>
      </a>
    </div>
  </div>
</section>

</main>

<?php require 'includes/footer.php'; ?>

